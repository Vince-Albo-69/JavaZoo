import java.util.concurrent.ThreadLocalRandom;
/**
 * Write a description of class RandomTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RandomTester
{
    public static void main()
    {
        int randomNum = ThreadLocalRandom.current().nextInt(1, 5);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        System.out.println(randomNum);
        
    }
    
    }
