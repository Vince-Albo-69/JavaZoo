
/**
 * Write a description of class Snake here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bella extends Animal implements Walking, Flying
{
    public Bella()
    {
        /*
         *  Call my other constructor that takes two Strings
         *  Again, this is called constructotr chaining
         */
        this("Donta the Bella", "Loves to eat the face off of people.");
    }
    
    public Bella(String name, String description)
    {
        /*
         * super means call something in my parent class (Animal), in this
         * case I am calling the constructor in my aprent that takes
         * two paramenters and sending in the name and description that 
         * were passed into this constructor
         */
        
        
        super(name, description);
    }
    
    @Override
    public String eat()
    {
        return "Eats people and rocks";
    }
    
    @Override
    public String makeNoise()
    {
        return "CAAAA CAAAA COOOO CAAAA COOOOO";
    }
    
    @Override
    public String walk()
    {
        return "*trips* *falls*";
    }
    
    @Override
    public String fly()
    {
        return "ZOOOOOOOMMMMMM ZZZZOOOOOOOOMMMMMMMM";
    }
}
