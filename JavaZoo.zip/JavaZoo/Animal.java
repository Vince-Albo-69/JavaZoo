
/**
 * Write a description of class Animal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Animal
{
    protected String name;
    protected String description;
    
    public static int numAnimals = 0;
    
    public Animal()
    {
        // Call the other constructor that takes one String parameter,
        // passing in one for the name
        // This is called constructor chaining when on constructor
        // calls anther
        this("none");
    }
    
    public Animal(String name)
    {
        //Call the other constructor that takes two String paremeters,
        // passing in the value referenced by the name variable and
        // non for the description
        this(name, "none");
    }
    
    public Animal(String name, String description)
    {
        // Sets the name and description for the animal
        this.name = name;
        this.description = description;
        // Increment the numAnimals indicating that another
        // animal has been created
        numAnimals++;
    }
    
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public void setDescription(String description)
    {
        this.description = description;
    }
    
    public String getDescription()
    {
        return this.description;
    }
    
    @Override /* This annotation (basiclly java metedata or data adout data)
               * means that we are telling the compiler to check to make sure
               * a parent (super class) contains a toString() method
               */
              
    public String toString()
    {
        return this.name + "; " + this.description;
    }
    
    /*
     * Abstract methods do not have a body. they define that any
     * class that inherits (extends) from this class must override
     * this method i.e. if Rhino extends Animal, it must have an eat()
     * method
     */
    
    public abstract String eat();
    
  
    public abstract String makeNoise();
}