
public interface Swimming
{
    public String swim();
}
