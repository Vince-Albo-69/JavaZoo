
/**
 * Abstract class Pigeon - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Moblin extends Animal implements Walking
{

    /**
     * Construction for objects of class moblin
     */
    public Moblin()
    {
        this("Murray the moblin" , "Once dressed up as John for Holloween");
    }
    public Moblin(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "meat meat meat";
    }
    @Override
    public String makeNoise()
    {
        return "*incoherent groan*";
    }
    @Override
    public String walk()
    {
        return "thud thud thud";
    }
    
    
}
