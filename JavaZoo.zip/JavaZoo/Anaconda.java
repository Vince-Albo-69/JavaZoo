
/**
 * Write a description of class Rhino here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Anaconda extends Animal
implements Walking
{
    public Anaconda()
    {
        // initialise instance variables
        this("sss the Anaconda", "SSSSSSSSSS");
    }

    public Anaconda(String name, String description) {
        super(name, description);
    }
    
    @Override
    public String eat(){
        return "Chews on Rat Flesh";
    }
    
    @Override
    public String makeNoise(){
        return "sssss";
    }
    
    @Override
    public String walk()
    {
       return "Slither"; 
    }
}
