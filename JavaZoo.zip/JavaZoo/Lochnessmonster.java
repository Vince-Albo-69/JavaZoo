
/**
 * Write a description of class Snake here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lochnessmonster extends Animal implements Walking, Swimming
{
    public Lochnessmonster()
    {
        /*
         *  Call my other constructor that takes two Strings
         *  Again, this is called constructotr chaining
         */
        this("Jequis the Loch ness monster", "Lives in deep dark ocean water and attacts ships");
    }
    
    public Lochnessmonster(String name, String description)
    {
        /*
         * super means call something in my parent class (Animal), in this
         * case I am calling the constructor in my aprent that takes
         * two paramenters and sending in the name and description that 
         * were passed into this constructor
         */
        
        
        super(name, description);
    }
    
    @Override
    public String eat()
    {
        return "Eats people and sea creatures";
    }
    
    @Override
    public String makeNoise()
    {
        return "Splasher splasy splash";
    }
    
    @Override
    public String walk()
    {
        return "Weeeeee";
    }
    
      @Override
    public String swim()
    {
        return "*Swish* *Swish* *Swish*";
    }
}
