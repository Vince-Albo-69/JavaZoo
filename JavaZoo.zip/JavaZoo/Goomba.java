/**
 * Write a description of class goomba here. - it's a goomba
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class Goomba extends Animal implements Walking, Flying
{
    // instance variables - replace the example below with your own
    public Goomba()
    {
        this("Goombro the Goomba","Uh, my head hurts");
    }
    public Goomba(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Eats dirts and if they are lucky a super mushroom";
    }
    @Override
    public String makeNoise()
    {
        return "Kew Kew";
    }
    @Override
    public String walk()
    {
        return "The Goomba walks back and forth for hours, like it's his life goal to walk. . . ";
    }
    @Override
    public String fly()
    {
        return "goomba can now fly, humnaity is doomed";
    }
}

