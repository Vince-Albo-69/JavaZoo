import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Zoo
{
    static String ami = "";
    static String fights = "";
    /**
    static String atc1 = "";
    static String atc2 = "";
    static String atc3 = "";
    static String atc4 = "";
    static int atcA1 = 0;
    static int atcA2 = 0;
    static int atcA3 = 0;
    static int atcA4 = 0;
    */

   static String aniName = "";
   
    static int aHealth = 10;
    static int health = 30;

    static int xp = 0;
    static int leval = 0;

    static String yAtc1 = "";
    static String yAtc2 = "";
    static String yAtc3 = "";
    static String yAtc4 = "";
    
    static String name = "";
    
    static int yAtcA1 = 0;
    static int yAtcA2 = 0;
    static int yAtcA3 = 0;
    static int yAtcA4 = 0;

    
    
    static int eni = 0;
    static int blah = 0;
    public static void main(String[] args) throws InterruptedException
    {
        List<Animal> animals = new ArrayList <>();

        System.out.println("🄵🄸🄶🄷🅃 🄲🄻🅄🄱 🅉🄾🄾! \n");
        System.out.println("Angering Animals");
        delayDots(3);
        System.out.println("Prepareing Your Weapons");
        populateAnimals(animals);
        delayDots(3);
        System.out.println("Arming Gaurds");
        delayDots(3);

        Scanner in = new Scanner(System.in);
        System.out.println("\nYou Ready to fight some animals?");
        System.out.println("Type help to find out what you can do. \n");

        String text = in.nextLine();
        String msg = " ";
        while(!text.equals("leave"))
        {
            switch(text)
            {
                default : msg = " You're legally retarded";
                case"help" : 
                msg = " ☞ You can look around, look up, or look in pond \n ☞ Fight \n ☞ leave \n ☞ listen to noises /n ☞ lunch time" ;
                break;

                case "vist cages" :
                msg = vistCages(animals);
                break;

                case "lunch time":
                msg = lunchTime(animals);
                break;

                case "listen to noises":
                msg = listenNoises(animals);
                break;

                case "look around":
                msg = animalWalking(animals);
                break;

                case "look up":
                msg = animalFlying(animals);
                break;

                case "look in pond":
                msg = animalSwimming(animals);
                break;

                case "Fight":
                
                fighter();

                msg = "";
                break;
            }
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("What now");
            text = in.nextLine();
        }

        
        // Prin out hoe many animals there were
        System.out.println("There were " + Animal.numAnimals + 
            " animals created and added to the list.");
    }

    /**
     * Prints an ellispse with a 1 seocnd between each dot
     * It then mves to next line
     */
    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i = 0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print("✱ ");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

    public static void populateAnimals(List<Animal> animals)
    {

        Abominablesnowman a1 = new Abominablesnowman();
        Bella a2 = new Bella();
        Bigfoot a3 = new Bigfoot();
        RedCrowCrane a4 = new RedCrowCrane();
        Trex a5 = new Trex();
        Vince a6 = new Vince();
        Megalodon a7 = new Megalodon();
        Platypus a8 = new Platypus();
        SunBear a9 = new SunBear();
        LR57CombatDroid a10 = new LR57CombatDroid();
        Phish a11 = new Phish();
        Walter a12 = new Walter();
        Bunny a13 = new Bunny();
        GoldFish a14 = new GoldFish();
        Thwomp a15 = new Thwomp();
        Shark a16 = new Shark();
        Goomba a17 = new Goomba();
        Rhino a18 = new Rhino();
        Llama a19 = new Llama();
        Droid a20 = new Droid();
        RedPanda a21 = new RedPanda();
        Anaconda a22 = new Anaconda();
        Duck a23 = new Duck();
        IronTarkus a24 = new IronTarkus();
        FleshMonster a25 = new FleshMonster();
        Moblin a26 = new Moblin();
        Lizalfo a27 = new Lizalfo();
        Bokoblin a28 = new Bokoblin();
        MourningDove a29 = new MourningDove();
        NakedMoleRats a30 = new NakedMoleRats();
        Lochnessmonster a31 = new Lochnessmonster();
        
        animals.add(a1);
        animals.add(a2);
        animals.add(a3);
        animals.add(a4);
        animals.add(a5);
        animals.add(a6);
        animals.add(a7);
        animals.add(a8);
        animals.add(a9);
        animals.add(a10);
        animals.add(a11);
        animals.add(a12);
        animals.add(a13);
        animals.add(a14);
        animals.add(a15);
        animals.add(a16);
        animals.add(a17);
        animals.add(a18);
        animals.add(a19);
        animals.add(a20);
        animals.add(a21);
        animals.add(a22);
        animals.add(a23);
        animals.add(a24);
        animals.add(a25);
        animals.add(a26);
        animals.add(a27);
        animals.add(a28);
        animals.add(a29);
        animals.add(a30);
        animals.add(a31);
    }

    public static String vistCages(List<Animal> animals)
    {
        String msg = " ";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      " + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String lunchTime(List<Animal> animals)
    {
        String msg = " ";
        for(Animal a : animals)
        {
            msg += a.getName() + "\n" + a.eat();
        }
        return msg;
    }

    public static String listenNoises(List<Animal> animals)
    {
        String msg = " ";
        for(Animal a : animals)
        {
            msg += a.getName() + "\n" + a.makeNoise();
        }
        return msg;
    }

    public static String animalWalking(List<Animal> animals)
    {
        String msg = " ";
        for(Animal a : animals)
        {
            if(a instanceof Walking)
            {
                Walking w = (Walking) a;
                msg += a.getName() + "\n" + w.walk()+ "\n";
            }
        }
        return msg;
    }

    public static String animalSwimming(List<Animal> animals)
    {
        String msg = " ";
        for(Animal a : animals)
        {
            if(a instanceof Swimming)
            {
                Swimming s = (Swimming) a;
                msg += a.getName() + "\n" + s.swim()+ "\n";
            }
        }
        return msg;
    }

    public static String animalFlying(List<Animal> animals)
    {
        String msg = " ";
        for(Animal a : animals)
        {
            if(a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg += a.getName() + "\n" + f.fly()+ "\n";
            }
        }
        return msg;
    }

    public static String fighter()
    {
        String msg = " ";
        
        System.out.println("Enther your membership ID (Probaly 12345678)");
        String fight = UserInput.getString();
        
        if (fight.indexOf("12345678")> -1)
            {
                System.out.println("Witch aniamls would you like to fight");
            }
        String ami = UserInput.getString();

        if (ami.indexOf("Abominablesnowman")>-1 || ami.indexOf("Bella")> -1 || ami.indexOf("Bigfoot")> -1 || ami.indexOf("RedCrowCrane")> -1 || ami.indexOf("Trex")> -1 || ami.indexOf("Vince")> -1 || ami.indexOf("Megalodon")> -1 || ami.indexOf("Platypus")> -1 || ami.indexOf("SunBear")> -1 || ami.indexOf("LR57CombatDroid")> -1 || ami.indexOf("Phish")> -1 || ami.indexOf("Walter")> -1 || ami.indexOf("Bunny")> -1 || ami.indexOf("GoldFish") > -1 || ami.indexOf("Thwomp")> -1 || ami.indexOf("Shark")> -1 || ami.indexOf("Goomba")> -1 || ami.indexOf("Rhino")> -1 || ami.indexOf("Llama")> -1 || ami.indexOf("Droid")> -1 || ami.indexOf("RedPanda")> -1 || ami.indexOf("Anaconda")> -1 || ami.indexOf("Duck")> -1 || ami.indexOf("IronTarkus")> -1 || ami.indexOf("FleshMonster")> -1 || ami.indexOf("Moblin")> -1 || ami.indexOf("Lizalfo")> -1 || ami.indexOf("Bokoblin")> -1 || ami.indexOf("MourningDove")> -1 || ami.indexOf("NakedMoleRats")> -1 || ami.indexOf("Lochnessmonster") > -1) 
        {
            aniName = ami;
        }
        else
        {
            System.out.println("That animals is not in the Zoo");
            System.exit(0); 
        }
       
        if (xp >= 10)
        {
            leval = 1;
            xp = 0;
        }
        else if (xp >= 20)
        {
            leval = 2;
            xp = 0;
        }
        else if (xp >= 30)
        {
            leval = 3;
            xp = 0;
        }
        else if (xp >=40)
        {
            leval = 4;
            xp = 0;
        }
        else if (xp >= 50)
        {
            leval = 5;
            xp = 0;
        }

        
        if (leval == 0)
        {
            yAtc1 = "light punch";
            yAtcA1 = 3;

            yAtc2 = "light kick";
            yAtcA2 = 4;

            yAtc3 = "shoot with bb gun";
            yAtcA3 = 5;

            yAtc4 = "Head but";
            yAtcA4 = 6;

        }
        else if (leval == 1)
        {
            yAtc1 = "hard punch";
            yAtcA1 = 4;

            yAtc2 = "hard kick";
            yAtcA2 = 5;

            yAtc3 = "shoot with 9mm pistol";
            yAtcA3 = 6;

            yAtc4 = "stab with knife";
            yAtcA4 = 8;
            aHealth = aHealth + 20;
            health = health + 20;
        }
        else if (leval == 2)
        {
            yAtc1 = "power punch";
            yAtcA1 = 5;

            yAtc2 = "power kick";
            yAtcA2 = 6;

            yAtc3 = "shoot with 20 gage shot gun";
            yAtcA3 = 7;

            yAtc4 = "stab with sword";
            yAtcA4 = 9;
            aHealth = aHealth + 25;
            health = health + 25;
        }
        else if (leval == 3)
        {
            yAtc1 = "super punch";
            yAtcA1 = 6;

            yAtc2 = "super kick";
            yAtcA2 = 7;

            yAtc3 = "shoot with 12 gage shot gun";
            yAtcA3 = 8;

            yAtc4 = "stab with long sword";
            yAtcA4 = 10;
            aHealth = aHealth + 30;
            health = health + 30;
        }
        else if (leval == 4)
        {
            yAtc1 = "super power punch";
            yAtcA1 = 8;

            yAtc2 = "super power kick";
            yAtcA2 = 9;

            yAtc3 = "shoot with AR15";
            yAtcA3 = 10;

            yAtc4 = "stab with poison sword";
            yAtcA4 = 12;
            aHealth = aHealth + 35;
            health = health + 35;
        }
        else if (leval == 5)
        {
            yAtc1 = "mega punch";
            yAtcA1 = 10;

            yAtc2 = "maga kick";
            yAtcA2 = 12;

            yAtc3 = "shoot with Flame Thrower";
            yAtcA3 = 15;

            yAtc4 = "stab with posion long sword";
            yAtcA4 = 20;
            aHealth = aHealth + 40;
            health = health + 45;
        }

        System.out.println("Your Health = " + health);
        System.out.println("Your Leval = " + leval);
        System.out.println("Your Xp = " + xp + "/10");

            
        while(health > 0 && aHealth > 0)
        {
            System.out.println("Be ready to fight the " + ami);
            System.out.println();
            System.out.println("What move do you choose");
            System.out.println("1: " + yAtc1 + " 2: " + yAtc2 + " 3; " + yAtc3 + " 4; " + yAtc4);
            System.out.println("1 , 2, 3, or 4");
            System.out.println("Or use /heal to gain health");
            System.out.println();
            String att = UserInput.getString();

            if(att.equals("1"))
            {
                blah = yAtcA1;
            }
            else if(att.equals("2"))
            {
                blah =  yAtcA2;
            }
            else if(att.equals("3"))
            {
                blah =  yAtcA3;
            }
            else if(att.equals("4"))
            {
                blah =  yAtcA4;
            }
            else if(att.equals("/heal"))
            {
                health = health + 20;
            }
            else
            {
                System.out.println("you missed");
                blah = 0;
            }
            
            int randomNum1 = ThreadLocalRandom.current().nextInt(1, 5); 
            if(randomNum1 == 1)
            {
                eni = 5;
                name = "light kick";
            }
            else if(randomNum1 == 2)
            {
                eni = 15;
                name = "Face punch";
            }
            else if(randomNum1 == 3)
            {
                eni = 10;
                name = "Bite";
            }
            else if(randomNum1 == 4)
            {
                eni = 20;
                name = "Super Punch";
            }
            
            health = health -  eni;
            aHealth = aHealth - blah;
            
            System.out.println(aniName + " uses " + name);
            System.out.println("Your health is: " + health);
            System.out.println("The animals's health is: " + aHealth);

        }
         System.out.println();
        if(aHealth < 0)
        {
            xp = xp + 10;
            System.out.println("You killed the animal and earned 10 xp");
            health = health + 25;
        }
        if(health < 0)
        {
            System.out.println("You died");
        }

        return msg;
    }
}
